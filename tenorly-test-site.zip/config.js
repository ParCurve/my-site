// EDIT THIS ONE FILE to rename your site, set your email and newsletter link.
var SITE = {
  name: "Tenorly",
  tagline: "US and UK bond and income data, explained.",
  author: "Zack",
  email: "hello@tenorly.com",
  newsletterUrl: "#"   // paste your newsletter signup link here, e.g. https://yourname.substack.com
};
(function () {
  var nav = '<a href="/">Home</a><a href="/yield-curve-explained/">Yield curve</a><a href="/about/">About</a><a href="/methodology/">Methodology</a>';
  var h = document.getElementById("site-header");
  if (h) h.innerHTML = '<header class="site"><div class="wrap bar"><a class="brand" href="/">' + SITE.name + '</a><nav aria-label="Main">' + nav + '</nav></div></header>';
  var f = document.getElementById("site-footer");
  if (f) {
    var sign = SITE.newsletterUrl && SITE.newsletterUrl !== "#" ? '<p><a href="' + SITE.newsletterUrl + '">Get the weekly rates briefing by email</a></p>' : "";
    f.innerHTML = '<footer class="site"><div class="wrap">' + sign +
      '<p>' + SITE.name + ' publishes education and data, not financial, tax or legal advice. <a href="/disclaimer/">Read the full disclaimer</a>. Found an error? <a href="mailto:' + SITE.email + '">Email ' + SITE.email + '</a>.</p>' +
      '<p>Sources and update process: <a href="/methodology/">methodology</a>.</p></div></footer>';
  }
  document.querySelectorAll("[data-site-name]").forEach(function (el) { el.textContent = SITE.name; });
  var s = document.getElementById("signup");
  if (s) { if (SITE.newsletterUrl && SITE.newsletterUrl !== "#") { s.href = SITE.newsletterUrl; } else { s.style.display = "none"; } }
})();
